Some helper functions for interacting with AWS S3 and YML config files

#### Details
Currently contains several functions primarily for interacting with AWS S3, typically used in the L of an ETL pipeline

Status: WIP