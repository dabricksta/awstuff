from setuptools import setup

setup(name='awstuff',
      version='0.211',
      description='Helper functions for interacting with AWS and other misc tasks',
      packages=['awstuff'],
      author_email='danieldbrickell@gmail.com',
      zip_safe=False)
